package ud6.coleccionesejercicios;

public interface Pila<T> {

    public void apilar(T t);
    public T desapilar();

}
