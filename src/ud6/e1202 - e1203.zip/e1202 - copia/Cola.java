package ud6.e1202;

public interface Cola<T> {
    public void encolar(T e);
    public T desencolar();
}
