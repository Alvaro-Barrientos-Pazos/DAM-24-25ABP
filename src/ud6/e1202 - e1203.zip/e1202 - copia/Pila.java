package ud6.e1202;

public interface Pila<T> {

    public void apilar(T t);
    public T desapilar();

}
